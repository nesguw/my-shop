from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    full_name = models.CharField('Полное имя', max_length=255)
    phone = models.CharField('Телефон', max_length=20)
    is_admin = models.BooleanField('Администратор', default=False)

    groups = models.ManyToManyField(
        'auth.Group',
        related_name='main_user_set',
        blank=True,
        verbose_name='groups'
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='main_user_set',
        blank=True,
        verbose_name='user permissions'
    )

class Category(models.Model):
    name = models.CharField('Название', max_length=100)
    slug = models.SlugField(unique=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True)

    def get_ancestors(self):
        ancestors = []
        category = self
        while category.parent:
            ancestors.insert(0, category.parent)
            category = category.parent
        return ancestors

class Product(models.Model):
    name = models.CharField('Название', max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField('Описание')
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2)
    old_price = models.DecimalField('Старая цена', max_digits=10, decimal_places=2, blank=True, null=True)
    discount_percent = models.PositiveIntegerField('Скидка %', default=0)
    image = models.ImageField('Изображение', upload_to='products/', blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    in_stock = models.BooleanField('В наличии', default=True)

    def get_discounted_price(self):
        if self.old_price and self.old_price > self.price:
            return self.price
        if self.discount_percent > 0:
            return self.price * (100 - self.discount_percent) / 100
        return self.price

    def get_old_price(self):
        if self.old_price:
            return self.old_price
        if self.discount_percent > 0:
            return self.price
        return None

class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    session_key = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def get_total_price(self):
        return sum(item.get_total_price() for item in self.items.all())

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def get_total_price(self):
        return self.product.get_discounted_price() * self.quantity

class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Ожидает оплаты'),
        ('paid', 'Оплачен'),
        ('processing', 'В обработке'),
        ('delivered', 'Доставлен'),
        ('cancelled', 'Отменен'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    session_key = models.CharField(max_length=100, null=True, blank=True)
    total_amount = models.DecimalField('Сумма', max_digits=10, decimal_places=2)
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='pending')
    first_name = models.CharField('Имя', max_length=100, blank=True)
    last_name = models.CharField('Фамилия', max_length=100, blank=True)
    phone = models.CharField('Телефон', max_length=20, blank=True)
    email = models.EmailField('Email', blank=True)
    delivery_address = models.TextField('Адрес доставки', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    yookassa_payment_id = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f'Заказ #{self.id} - {self.get_status_display()}'

class Wishlist(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='wishlist')
    products = models.ManyToManyField(Product, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Избранное {self.user.username}'