from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.db import models
from django.core.paginator import Paginator  # ← ЭТУ СТРОКУ ДОБАВИТЬ
from .models import Product, Category, Cart, CartItem, Order, Wishlist
import uuid
from yookassa import Configuration, Payment
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import json
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required

@csrf_exempt
def payment_callback(request):
    # Получаем данные от ЮKassa
    event_json = json.loads(request.body)
    
    # Проверяем, что это уведомление об оплате
    if event_json.get('event') == 'payment.succeeded':
        payment_id = event_json['object']['id']
        order_id = event_json['object']['metadata']['order_id']
        
        # Обновляем статус заказа
        order = Order.objects.get(id=order_id)
        order.status = 'paid'
        order.save()
    
    return HttpResponse(status=200)

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('profile')
        else:
            # Выводим ошибки прямо на страницу
            return render(request, 'main/register.html', {'form': form, 'errors': form.errors})
    else:
        form = UserCreationForm()
    return render(request, 'main/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('profile')
        else:
            return render(request, 'main/login.html', {'error': 'Неверный логин или пароль'})
    return render(request, 'main/login.html')

def logout_view(request):
    logout(request)
    return redirect('catalog')

@login_required
def profile(request):
    # Временно отключаем заказы, чтобы личный кабинет работал
    orders = []
    return render(request, 'main/profile.html', {
        'user': request.user,
        'orders': orders,
    })

@login_required
def update_profile(request):
    if request.method == 'POST':
        user = request.user
        user.email = request.POST.get('email', '')
        user.first_name = request.POST.get('first_name', '')
        user.last_name = request.POST.get('last_name', '')
        user.save()
    return redirect('profile')


def get_cart(request):
    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
    else:
        session_key = request.session.session_key
        if not session_key:
            request.session.create()
            session_key = request.session.session_key
        cart, created = Cart.objects.get_or_create(session_key=session_key)
    return cart

def catalog(request, category_slug=None):
    products = Product.objects.filter(in_stock=True)
    categories = Category.objects.all()
    selected_category = None
    search_query = request.GET.get('q', '')
    sort_by = request.GET.get('sort', '')
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')
    only_in_stock = request.GET.get('only_in_stock', '')
    
    # Фильтр по категории
    if category_slug:
        selected_category = Category.objects.get(slug=category_slug)
        products = products.filter(category=selected_category)
    
    # Поиск по названию и описанию
    if search_query:
        products = products.filter(
            models.Q(name__icontains=search_query) |
            models.Q(description__icontains=search_query)
        )
    
    # Фильтр по цене
    if min_price:
        try:
            min_price = float(min_price)
            products = products.filter(price__gte=min_price)
        except ValueError:
            pass
    if max_price:
        try:
            max_price = float(max_price)
            products = products.filter(price__lte=max_price)
        except ValueError:
            pass
    
    # Фильтр: только в наличии
    if only_in_stock:
        products = products.filter(in_stock=True)
    
    # Сортировка товаров
    if sort_by == 'price_asc':
        products = products.order_by('price')
    elif sort_by == 'price_desc':
        products = products.order_by('-price')
    elif sort_by == 'name_asc':
        products = products.order_by('name')
    elif sort_by == 'name_desc':
        products = products.order_by('-name')
    else:
        products = products.order_by('-id')
    
    # Пагинация (6 товаров на страницу)
    paginator = Paginator(products, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Минимальная и максимальная цена для слайдера
    all_products = Product.objects.filter(in_stock=True)
    price_min = all_products.order_by('price').first().price if all_products else 0
    price_max = all_products.order_by('-price').first().price if all_products else 100000
    
    context = {
        'products': page_obj,
        'categories': categories,
        'selected_category': selected_category,
        'cart': get_cart(request),
        'search_query': search_query,
        'sort_by': sort_by,
        'page_obj': page_obj,
        'min_price': min_price,
        'max_price': max_price,
        'price_min': int(price_min),
        'price_max': int(price_max),
        'only_in_stock': only_in_stock,
    }
    return render(request, 'main/catalog.html', context)

def add_to_cart(request, product_id):
    cart = get_cart(request)
    product = get_object_or_404(Product, id=product_id)
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('cart')

def cart_view(request):
    cart = get_cart(request)
    return render(request, 'main/cart.html', {'cart': cart})

def update_cart_item(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id)
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 1))
        if quantity > 0:
            cart_item.quantity = quantity
            cart_item.save()
        else:
            cart_item.delete()
    return redirect('cart')

def remove_from_cart(request, item_id):
    try:
        cart_item = CartItem.objects.get(id=item_id)
        cart_item.delete()
    except CartItem.DoesNotExist:
        pass  # Просто ничего не делаем, если товара нет
    return redirect('cart')

def clear_cart(request):
    cart = get_cart(request)
    cart.items.all().delete()
    return redirect('cart')

def checkout(request):
    cart = get_cart(request)
    
    if cart.items.count() == 0:
        return redirect('catalog')
    
    if request.method == 'POST':
        first_name = request.POST.get('first_name', '')
        last_name = request.POST.get('last_name', '')
        phone = request.POST.get('phone', '')
        email = request.POST.get('email', '')
        delivery_address = request.POST.get('delivery_address', '')
        
        order = Order.objects.create(
            user=request.user if request.user.is_authenticated else None,
            session_key=request.session.session_key,
            total_amount=cart.get_total_price(),
            status='pending',
            first_name=first_name,
            last_name=last_name,
            phone=phone,
            email=email,
            delivery_address=delivery_address,
        )
        
        cart.items.all().delete()
        
        messages.success(request, f'Заказ #{order.id} успешно оформлен!')
        return redirect('order_success', order_id=order.id)
    
    context = {
        'cart': cart,
        'cart_items': cart.items.all(),
    }
    return render(request, 'main/checkout.html', context)

def order_success(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    return render(request, 'main/order_success.html', {'order': order})


def create_payment(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    # Тестовая оплата — меняем статус на paid
    order.status = 'paid'
    order.save()
    messages.success(request, f'Заказ #{order.id} успешно оплачен (тестовый режим)!')
    return redirect('order_success', order_id=order.id)

def product_detail(request, product_slug):
    product = get_object_or_404(Product, slug=product_slug, in_stock=True)
    
    # Рекомендации: другие товары из той же категории (исключая текущий)
    recommendations = Product.objects.filter(
        category=product.category,
        in_stock=True
    ).exclude(id=product.id)[:4]  # максимум 4 товара
    
    return render(request, 'main/product_detail.html', {
        'product': product,
        'recommendations': recommendations,
    })


@login_required
def add_to_wishlist(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    wishlist, created = Wishlist.objects.get_or_create(user=request.user)
    wishlist.products.add(product)
    return redirect(request.META.get('HTTP_REFERER', 'catalog'))

@login_required
def remove_from_wishlist(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    wishlist = Wishlist.objects.get(user=request.user)
    wishlist.products.remove(product)
    return redirect('wishlist')

@login_required
def wishlist_view(request):
    wishlist, created = Wishlist.objects.get_or_create(user=request.user)
    return render(request, 'main/wishlist.html', {'wishlist': wishlist})